﻿// Author: Davion Clark
// Date: 9/8/2019
// Class: CPSC 3175

using System;
using System.Collections.Generic;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MineSweeper
{
    class Program
    {
        static void Main(string[] args)
        {
            int width = 10;
            int height = 10;
            int numberOfMines = 20;
            Grid tGrid = new Grid(width, height, numberOfMines);

            Console.ReadKey();
        }
    }

    enum CellState { OPEN, CLOSED, FLAGGED }

    class Cell
    {
        private Boolean mine;
        public Boolean Mine { set; get; }

        private int minesAround;
        public int MinesAround { set; get; }

        private CellState state;
        public CellState State { set; get; }

        public Cell ()
        {
            State = CellState.OPEN;
            Mine = false;

        }

        public void open()
        {

        }

        public void close()
        {

        }

        public void flag()
        {
        
        }

        override
        public String ToString()
        {
            if (State == CellState.OPEN && Mine == true)
            {
                return "M"; //Mines are represented by 'M'
            }
            else
            {
                return MinesAround.ToString();
            }
        }
    }

    class Grid
    {
        private Cell[,] grid;

        // Designated Constructor
        public Grid (int width, int height, int numberOfMines)
        {
            grid = new Cell[width, height];

            // Place the mines randomly here
            Random mine = new Random();

            //Initializes every object in the 2d array
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    grid[x, y] = new Cell();
                }
            }

            //Creates bombs and places them in random spots in the array
            for (int i = 0; i < numberOfMines; i++)
            {
                int x = mine.Next(0, width);
                int y = mine.Next(0, height);

                if (grid[x, y].Mine == false)
                { 
                    grid[x, y].Mine = true;
                }
                else
                {
                    i--;
                }
            }

            //MinesAround logic
            for (int i = 0; i < width; i++) //Loops rows
            {
                for (int j = 0; j < height; j++) //Loops columns
                {
                    int count = 0; 
                    if (grid[i, j].Mine == false) //If the current position in the array is not a mine
                    {
                        //Checks if coordinate y - 1 is within bounds
                        if (j - 1 >= 0)
                        {
                            //If nearby position is a mine, increase the value of counter by 1
                            if (grid[i, j - 1].Mine == true)
                            {
                                grid[i, j].MinesAround = count + 1;
                                count++;
                            }
                        }
                        
                        //y + 1
                        if (j + 1 < grid.GetLength(1))
                        {
                            if (grid[i, j + 1].Mine == true)
                            {
                                grid[i, j].MinesAround = count + 1;
                                count++;
                            }
                        }

                        //x - 1
                        if (i - 1 >= 0)
                        {
                            if (grid[i - 1, j].Mine == true)
                            {
                                grid[i, j].MinesAround = count + 1;
                                count++;
                            }

                            //y - 1
                            if (j - 1 >= 0)
                            {
                                if (grid[i - 1, j - 1].Mine == true)
                                {
                                    grid[i, j].MinesAround = count + 1;
                                    count++;
                                }
                            }

                            //y + 1
                            if (j + 1 < grid.GetLength(1))
                            {
                                if (grid[i - 1, j + 1].Mine == true)
                                {
                                    grid[i, j].MinesAround = count + 1;
                                    count++;
                                }
                            }
                        }

                        //x + 1
                        if (i + 1 < grid.GetLength(0))
                        {
                            if (grid[i + 1, j].Mine == true)
                            {
                                grid[i, j].MinesAround = count + 1;
                                count++;
                            }

                            //y - 1
                            if (j - 1 >= 0)
                            {
                                if (grid[i + 1, j - 1].Mine == true)
                                {
                                    grid[i, j].MinesAround = count + 1;
                                    count++;
                                }
                            }

                            //y + 1
                            if (j + 1 < grid.GetLength(1))
                            {
                                if (grid[i + 1, j + 1].Mine == true)
                                {
                                    grid[i, j].MinesAround = count + 1;
                                    count++;
                                }
                            }
                        }
                    }
                }
            }

            //Utilizes ToString() method to print out the grid
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    Console.Write(grid[i, j].ToString() +" ");
                }
                Console.WriteLine();
            }
        }

    }
}
